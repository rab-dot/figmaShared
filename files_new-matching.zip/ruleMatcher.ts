import { Rule as PrismaRule } from "@prisma/client";
import { prisma } from "./db";
import { keywordMatchesText } from "./textMatch";

export async function loadEnabledRules(igAccountId: string): Promise<PrismaRule[]> {
  return prisma.rule.findMany({
    where: { igAccountId, enabled: true },
    orderBy: { priority: "asc" },
  });
}

/** Возвращает первое подходящее правило, либо null */
export function matchRule(commentText: string, rules: PrismaRule[]): PrismaRule | null {
  for (const rule of rules) {
    if (rule.matchType === "ANY") {
      return rule;
    }

    const keywords = rule.keywords
      .split(",")
      .map((k) => k.trim())
      .filter(Boolean);

    const hit = keywords.some((kw) => keywordMatchesText(kw, commentText));
    if (hit) return rule;
  }

  return null;
}
