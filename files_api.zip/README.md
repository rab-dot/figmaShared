# ig-comment-bot — Этап 1 + Этап 2

Сервер, который слушает вебхуки Instagram (Meta Graph API) о новых комментариях,
сверяет текст с правилами из БД и отправляет автоответ в директ через Private Reply API.
Плюс CRUD-эндпоинты для управления правилами — на них будет опираться будущий фронтенд.

## Структура

```
prisma/
  schema.prisma            — модели БД: IgAccount, Rule, SentReply
  seed.ts                   — разовый перенос IG_ACCESS_TOKEN из .env в БД + пример правила
src/
  server.ts                — express-сервер: /webhook + /api/rules + /api/logs
  db.ts                     — единый инстанс PrismaClient
  config.ts                 — чтение .env
  verifySignature.ts        — проверка HMAC-подписи от Meta
  commentWebhookParser.ts   — разбор payload'а вебхука в удобный формат
  ruleMatcher.ts            — загрузка правил аккаунта из БД + сопоставление с текстом
  privateReply.ts           — отправка сообщения в директ через Graph API + лог в БД
  rulesRouter.ts            — CRUD /api/rules
  logsRouter.ts             — GET /api/logs, /api/logs/stats
  types.ts                  — общие типы
docker-compose.yml          — локальный Postgres для разработки
```

## Модель данных

- **IgAccount** — подключённый Instagram-аккаунт (ig-user-id + access token). Сейчас один,
  но модель уже готова к нескольким аккаунтам под одним пользователем в будущем.
- **Rule** — правило автоответа, привязано к аккаунту, приоритет определяет порядок проверки.
- **SentReply** — лог каждой попытки отправки (успех/ошибка), с уникальным ограничением
  `(igAccountId, commentId)` — это и есть защита от повторного ответа одному человеку.

## Настройка (Meta стороне)

1. Создайте приложение на https://developers.facebook.com/apps → тип "Business".
2. В настройках приложения добавьте себя как **Admin/Tester** (Roles → App roles) —
   это даёт Standard Access без App Review, если использовать только свой аккаунт.
3. Переведите ваш Instagram в **Professional (Business или Creator)** аккаунт
   и привяжите его к Facebook-странице.
4. В продукте **Webhooks** подпишитесь на объект `instagram`, поле `comments`.
5. В продукте **Instagram** → Generate Token получите access token для своего IG-аккаунта
   с правами `instagram_manage_comments`, `instagram_manage_messages`,
   `instagram_business_basic`.
6. App Secret возьмите в Settings → Basic.

## Настройка локально

```bash
cp .env.example .env
# заполните META_APP_SECRET, WEBHOOK_VERIFY_TOKEN (придумайте сами),
# IG_ACCESS_TOKEN, IG_BUSINESS_ACCOUNT_ID, DATABASE_URL

npm install

# поднимаем локальный Postgres (или используйте свой, тогда просто поправьте DATABASE_URL)
docker compose up -d

# генерируем клиент Prisma и накатываем миграцию
npm run db:generate
npm run db:migrate      # спросит имя миграции, например "init"

# переносим IG_ACCESS_TOKEN/IG_BUSINESS_ACCOUNT_ID из .env в БД + создаём пример правила
npm run db:seed

npm run dev
```

Сервер поднимется на `http://localhost:3000`. Посмотреть/поредактировать данные глазами
можно через `npm run db:studio` (откроет Prisma Studio в браузере).

## Публичный HTTPS для вебхука (локальная разработка)

Meta не примет `http://localhost` — нужен публичный HTTPS-адрес. Проще всего через ngrok:

```bash
ngrok http 3000
```

Скопируйте выданный `https://xxxx.ngrok-free.app` и в Meta App Dashboard → Webhooks
укажите Callback URL: `https://xxxx.ngrok-free.app/webhook`, Verify Token —
тот же, что в `.env` (`WEBHOOK_VERIFY_TOKEN`).

## API для управления правилами

`igAccountId` — это внутренний `id` записи в таблице `IgAccount` (не ig-user-id из Meta),
его можно посмотреть после seed в консоли или через Prisma Studio.

```bash
# Список правил
curl "http://localhost:3000/api/rules?igAccountId=clxxxx"

# Создать правило
curl -X POST http://localhost:3000/api/rules \
  -H "Content-Type: application/json" \
  -d '{
    "igAccountId": "clxxxx",
    "name": "Вопрос про доставку",
    "keywords": "доставка,отправка",
    "matchType": "CONTAINS",
    "reply": "Привет! Все детали по доставке отправила в директ 📦"
  }'

# Обновить (например, отключить)
curl -X PUT http://localhost:3000/api/rules/RULE_ID \
  -H "Content-Type: application/json" \
  -d '{"enabled": false}'

# Удалить
curl -X DELETE http://localhost:3000/api/rules/RULE_ID

# Статистика отправок
curl "http://localhost:3000/api/logs/stats?igAccountId=clxxxx"
```

- `matchType: "CONTAINS"` — сработает, если в комментарии есть хотя бы одно слово из `keywords`
  (через запятую).
- `matchType: "ANY"` — сработает на любой комментарий.
- `priority` — чем меньше число, тем раньше правило проверяется; срабатывает первое подходящее.
- `enabled: false` — правило временно не участвует в проверке.

## Ограничения, которые нужно держать в голове

- **Private Reply работает только ограниченное время** после комментария
  (у Meta это порядка 7 дней) — старые комментарии так не обработать.
- **Rate limits**: у Graph API лимит на количество вызовов в час на пользователя,
  при активном аккаунте это может стать узким местом (см. заголовки ответа API).
- Обработка вебхука всё ещё синхронная (без очереди) — если сервер упадёт между приёмом
  события и отправкой ответа, событие потеряется. Анти-дубль по `commentId` уже есть
  (таблица `SentReply` с уникальным индексом), но ретраев при сетевых сбоях пока нет.

## Следующие шаги

- Добавить очередь (Redis + BullMQ) между приёмом вебхука и отправкой private reply —
  сейчас `for` внутри хендлера выполняется синхронно, при пачке комментариев это может
  тормозить ответ Meta и не переживёт падение процесса.
- OAuth-флоу для получения и рефреша access token (сейчас он один раз кладётся в БД через
  `db:seed` вручную и не обновляется — long-lived токен живёт ~60 дней).
- Авторизация пользователей — как только появится фронтенд, `igAccountId` в query/body
  API нужно будет заменить на определение аккаунта из сессии/JWT текущего пользователя.
- Фронтенд на React 19 + TS поверх `/api/rules` и `/api/logs`.
