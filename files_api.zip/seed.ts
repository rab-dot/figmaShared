import "dotenv/config";
import { prisma } from "../src/db";

/**
 * Разово переносит данные из .env (IG_ACCESS_TOKEN, IG_BUSINESS_ACCOUNT_ID) в БД
 * и создаёт пару стартовых правил для примера.
 * Запуск: npm run db:seed
 */
async function main() {
  const igBusinessAccountId = process.env.IG_BUSINESS_ACCOUNT_ID;
  const accessToken = process.env.IG_ACCESS_TOKEN;

  if (!igBusinessAccountId || !accessToken) {
    throw new Error("Заполните IG_BUSINESS_ACCOUNT_ID и IG_ACCESS_TOKEN в .env перед seed");
  }

  const account = await prisma.igAccount.upsert({
    where: { igBusinessAccountId },
    update: { accessToken },
    create: { igBusinessAccountId, accessToken },
  });

  console.log(`✅ IgAccount готов: ${account.id} (${account.igBusinessAccountId})`);

  const existingRules = await prisma.rule.count({ where: { igAccountId: account.id } });
  if (existingRules > 0) {
    console.log(`ℹ️  У аккаунта уже есть ${existingRules} правил(a), пропускаем создание примеров`);
    return;
  }

  await prisma.rule.create({
    data: {
      igAccountId: account.id,
      name: "Вопрос про цену",
      keywords: "цена,стоимость,прайс",
      matchType: "CONTAINS",
      reply: "Привет! Скинула цену в директ 😊",
      priority: 0,
    },
  });

  console.log("✅ Создано стартовое правило-пример");
}

main()
  .catch((err) => {
    console.error("❌ Ошибка seed:", err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
