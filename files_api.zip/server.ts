import express, { Request, Response } from "express";
import { config } from "./config";
import { verifyMetaSignature } from "./verifySignature";
import { extractComments } from "./commentWebhookParser";
import { loadEnabledRules, matchRule } from "./ruleMatcher";
import { sendPrivateReply } from "./privateReply";
import { prisma } from "./db";
import { rulesRouter } from "./rulesRouter";
import { logsRouter } from "./logsRouter";
import { MetaWebhookBody } from "./types";

const app = express();

// Сырое тело нужно только для /webhook (проверка подписи), поэтому вешаем verify
// точечно, а не глобально — остальные роуты получают обычный распарсенный JSON.
app.use(
  express.json({
    verify: (req, _res, buf) => {
      (req as Request & { rawBody: Buffer }).rawBody = buf;
    },
  })
);

app.use("/api/rules", rulesRouter);
app.use("/api/logs", logsRouter);

/**
 * GET-эндпоинт для верификации вебхука при настройке в Meta App Dashboard.
 */
app.get("/webhook", (req: Request, res: Response) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === config.verifyToken) {
    console.log("[webhook] Верификация прошла успешно");
    res.status(200).send(challenge);
    return;
  }

  console.warn("[webhook] Верификация не пройдена: неверный token или mode");
  res.sendStatus(403);
});

/**
 * POST-эндпоинт, на который Meta шлёт реальные события (новые комментарии и т.д.)
 */
app.post("/webhook", async (req: Request, res: Response) => {
  const rawBody = (req as Request & { rawBody: Buffer }).rawBody;
  const signature = req.header("x-hub-signature-256") ?? undefined;

  if (!verifyMetaSignature(rawBody, signature)) {
    console.warn("[webhook] Невалидная подпись запроса — отклонено");
    res.sendStatus(401);
    return;
  }

  // Отвечаем Meta сразу 200, чтобы она не считала доставку неуспешной и не ретраила.
  // Обработку делаем уже после ответа (полноценная очередь — следующий шаг после этого).
  res.sendStatus(200);

  const body = req.body as MetaWebhookBody;

  for (const entry of body.entry ?? []) {
    // entry.id — это ig-user-id аккаунта, на который пришло событие
    const igAccount = await prisma.igAccount.findUnique({
      where: { igBusinessAccountId: entry.id },
    });

    if (!igAccount) {
      console.warn(`[webhook] Событие для неизвестного аккаунта ${entry.id}, пропускаем`);
      continue;
    }

    const comments = extractComments({ object: body.object, entry: [entry] });
    if (comments.length === 0) continue;

    const rules = await loadEnabledRules(igAccount.id);

    for (const comment of comments) {
      console.log(`[comment] @${comment.fromUsername ?? comment.fromUserId}: "${comment.text}"`);

      // Анти-дубль: если на этот commentId уже отправляли ответ — пропускаем
      const alreadySent = await prisma.sentReply.findUnique({
        where: {
          igAccountId_commentId: { igAccountId: igAccount.id, commentId: comment.commentId },
        },
      });
      if (alreadySent) {
        console.log(`[comment] Уже отвечали на этот комментарий, пропускаем`);
        continue;
      }

      const rule = matchRule(comment.text, rules);
      if (!rule) {
        console.log(`[comment] Правило не найдено, пропускаем`);
        continue;
      }

      console.log(`[comment] Совпало правило "${rule.name}" — отправляем private reply`);
      await sendPrivateReply({
        igAccountId: igAccount.id,
        igBusinessAccountId: igAccount.igBusinessAccountId,
        accessToken: igAccount.accessToken,
        comment,
        rule,
      });
    }
  }
});

app.listen(config.port, () => {
  console.log(`🚀 Сервер запущен на http://localhost:${config.port}`);
  console.log(`   Webhook endpoint: http://localhost:${config.port}/webhook`);
  console.log(`   API правил:       http://localhost:${config.port}/api/rules`);
  console.log(`   API логов:        http://localhost:${config.port}/api/logs`);
});
