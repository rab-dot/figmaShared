import express, { Request, Response } from "express";
import { config } from "./config";
import { verifyMetaSignature } from "./verifySignature";
import { extractComments } from "./commentWebhookParser";
import { loadRules, matchRule } from "./ruleMatcher";
import { sendPrivateReply } from "./privateReply";
import { MetaWebhookBody } from "./types";

const app = express();

// Важно: нам нужен доступ к "сырому" телу запроса для проверки HMAC-подписи,
// поэтому используем verify-хук express.json вместо обычного парсинга.
app.use(
  express.json({
    verify: (req, _res, buf) => {
      (req as Request & { rawBody: Buffer }).rawBody = buf;
    },
  })
);

/**
 * GET-эндпоинт для верификации вебхука при настройке в Meta App Dashboard.
 * Meta присылает hub.challenge, который нужно вернуть как есть, если verify_token совпал.
 */
app.get("/webhook", (req: Request, res: Response) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === config.verifyToken) {
    console.log("[webhook] Верификация прошла успешно");
    res.status(200).send(challenge);
    return;
  }

  console.warn("[webhook] Верификация не пройдена: неверный token или mode");
  res.sendStatus(403);
});

/**
 * POST-эндпоинт, на который Meta шлёт реальные события (новые комментарии и т.д.)
 */
app.post("/webhook", async (req: Request, res: Response) => {
  const rawBody = (req as Request & { rawBody: Buffer }).rawBody;
  const signature = req.header("x-hub-signature-256") ?? undefined;

  if (!verifyMetaSignature(rawBody, signature)) {
    console.warn("[webhook] Невалидная подпись запроса — отклонено");
    res.sendStatus(401);
    return;
  }

  // Отвечаем Meta сразу 200, чтобы она не считала доставку неуспешной и не ретраила.
  // Обработку делаем уже после ответа (на Этапе 2 это уйдёт в очередь).
  res.sendStatus(200);

  const body = req.body as MetaWebhookBody;
  const comments = extractComments(body);
  const rules = loadRules();

  for (const comment of comments) {
    console.log(`[comment] @${comment.fromUsername ?? comment.fromUserId}: "${comment.text}"`);

    const rule = matchRule(comment.text, rules);
    if (!rule) {
      console.log(`[comment] Правило не найдено, пропускаем`);
      continue;
    }

    console.log(`[comment] Совпало правило "${rule.id}" — отправляем private reply`);
    await sendPrivateReply(comment.commentId, rule.reply);
  }
});

app.listen(config.port, () => {
  console.log(`🚀 Сервер запущен на http://localhost:${config.port}`);
  console.log(`   Webhook endpoint: http://localhost:${config.port}/webhook`);
});
