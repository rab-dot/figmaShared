import fs from "node:fs";
import path from "node:path";
import { Rule } from "./types";

let cachedRules: Rule[] | null = null;

/**
 * На Этапе 1 правила лежат в JSON-файле. На Этапе 2 это станет запросом в БД,
 * поэтому сигнатура функции (rules-in, match-out) намеренно не завязана на файл.
 */
export function loadRules(): Rule[] {
  if (cachedRules) return cachedRules;

  const filePath = path.join(__dirname, "rules.json");
  const raw = fs.readFileSync(filePath, "utf-8");
  cachedRules = (JSON.parse(raw) as Rule[]).filter((r) => r.enabled !== false);
  return cachedRules;
}

/** Возвращает первое правило, подходящее под текст комментария, либо null */
export function matchRule(commentText: string, rules: Rule[]): Rule | null {
  const normalized = commentText.toLowerCase();

  for (const rule of rules) {
    if (rule.matchType === "any") {
      return rule;
    }

    if (rule.matchType === "contains") {
      const hit = rule.keywords.some((kw) => normalized.includes(kw.toLowerCase()));
      if (hit) return rule;
    }
  }

  return null;
}
