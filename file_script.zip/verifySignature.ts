import crypto from "node:crypto";
import { config } from "./config";

/**
 * Meta подписывает тело каждого POST-запроса на webhook HMAC-SHA256 с использованием
 * App Secret и присылает подпись в заголовке X-Hub-Signature-256.
 * Обязательно проверять это, иначе кто угодно сможет слать вам поддельные "комментарии".
 */
export function verifyMetaSignature(rawBody: Buffer, signatureHeader?: string): boolean {
  if (!signatureHeader) return false;

  const expected =
    "sha256=" + crypto.createHmac("sha256", config.appSecret).update(rawBody).digest("hex");

  const a = Buffer.from(expected);
  const b = Buffer.from(signatureHeader);

  // timingSafeEqual требует буферы одинаковой длины
  if (a.length !== b.length) return false;

  return crypto.timingSafeEqual(a, b);
}
