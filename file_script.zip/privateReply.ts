import axios from "axios";
import { config } from "./config";

/**
 * Private Reply — единственный способ Meta официально написать пользователю в Direct
 * "в ответ" на его комментарий, без обычной переписки. Работает ограниченное время
 * после самого комментария (около 7 дней), после чего Meta вернёт ошибку.
 *
 * Документация: POST /{ig-user-id}/messages с recipient.comment_id
 */
export async function sendPrivateReply(commentId: string, message: string): Promise<void> {
  const url = `https://graph.facebook.com/${config.graphApiVersion}/${config.igBusinessAccountId}/messages`;

  try {
    await axios.post(
      url,
      {
        recipient: { comment_id: commentId },
        message: { text: message },
      },
      {
        params: { access_token: config.igAccessToken },
      }
    );

    console.log(`[privateReply] Отправлено в ответ на комментарий ${commentId}`);
  } catch (err) {
    if (axios.isAxiosError(err)) {
      console.error(
        `[privateReply] Ошибка отправки для комментария ${commentId}:`,
        err.response?.data ?? err.message
      );
    } else {
      console.error(`[privateReply] Неизвестная ошибка для ${commentId}:`, err);
    }
    // На Этапе 2 сюда добавится запись в очередь на retry вместо простого лога
  }
}
