# ig-comment-bot — Этап 1

Скрипт, который слушает вебхуки Instagram (Meta Graph API) о новых комментариях,
сверяет текст с ключевыми словами и отправляет автоответ в директ через Private Reply API.

## Структура

```
src/
  server.ts               — express-сервер, GET/POST /webhook
  config.ts                — чтение .env
  verifySignature.ts       — проверка HMAC-подписи от Meta
  commentWebhookParser.ts  — разбор payload'а вебхука в удобный формат
  ruleMatcher.ts           — сопоставление текста комментария с правилами
  privateReply.ts          — отправка сообщения в директ через Graph API
  rules.json                — список правил "ключевое слово → текст ответа"
  types.ts                 — общие типы
```

## Настройка (Meta стороне)

1. Создайте приложение на https://developers.facebook.com/apps → тип "Business".
2. В настройках приложения добавьте себя как **Admin/Tester** (Roles → App roles) —
   это даёт Standard Access без App Review, если использовать только свой аккаунт.
3. Переведите ваш Instagram в **Professional (Business или Creator)** аккаунт
   и привяжите его к Facebook-странице.
4. В продукте **Webhooks** подпишитесь на объект `instagram`, поле `comments`.
5. В продукте **Instagram** → Generate Token получите access token для своего IG-аккаунта
   с правами `instagram_manage_comments`, `instagram_manage_messages`,
   `instagram_business_basic`.
6. App Secret возьмите в Settings → Basic.

## Настройка локально

```bash
cp .env.example .env
# заполните META_APP_SECRET, WEBHOOK_VERIFY_TOKEN (придумайте сами),
# IG_ACCESS_TOKEN, IG_BUSINESS_ACCOUNT_ID

npm install
npm run dev
```

Сервер поднимется на `http://localhost:3000`.

## Публичный HTTPS для вебхука (локальная разработка)

Meta не примет `http://localhost` — нужен публичный HTTPS-адрес. Проще всего через ngrok:

```bash
ngrok http 3000
```

Скопируйте выданный `https://xxxx.ngrok-free.app` и в Meta App Dashboard → Webhooks
укажите Callback URL: `https://xxxx.ngrok-free.app/webhook`, Verify Token —
тот же, что в `.env` (`WEBHOOK_VERIFY_TOKEN`).

## Как редактировать правила автоответа

Откройте `src/rules.json`:

```json
{
  "id": "price-rule",
  "keywords": ["цена", "стоимость"],
  "matchType": "contains",
  "reply": "Привет! Скинула цену в директ 😊"
}
```

- `matchType: "contains"` — сработает, если в комментарии есть хотя бы одно слово из `keywords`.
- `matchType: "any"` — сработает на любой комментарий (keywords можно оставить пустым).
- `enabled: false` — временно отключить правило.
- Правила проверяются по порядку сверху вниз, срабатывает первое подходящее.

После изменения файла перезапустите `npm run dev` (кэш правил читается один раз при старте).

## Ограничения, которые нужно держать в голове

- **Private Reply работает только ограниченное время** после комментария
  (у Meta это порядка 7 дней) — старые комментарии так не обработать.
- **Rate limits**: у Graph API лимит на количество вызовов в час на пользователя,
  при активном аккаунте это может стать узким местом (см. заголовки ответа API).
- Сейчас обработка полностью синхронная и без сохранения состояния — если сервер
  упадёт между вебхуком и отправкой ответа, событие потеряется. Это нормально
  для Этапа 1, на Этапе 2 добавляем БД + очередь (Redis/BullMQ) для надёжности
  и защиты от повторной отправки одному человеку.

## Следующие шаги (Этап 2)

- Перенести `rules.json` в Postgres (Prisma/Drizzle).
- Добавить очередь на обработку событий вместо синхронного `for` в хендлере.
- Логировать все отправки в БД (для анти-дублей и статистики).
- OAuth-флоу для получения и рефреша `IG_ACCESS_TOKEN` (сейчас он статичный в `.env`).
