import "dotenv/config";

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Отсутствует обязательная переменная окружения: ${name}`);
  }
  return value;
}

export const config = {
  port: Number(process.env.PORT ?? 3000),
  appSecret: required("META_APP_SECRET"),
  verifyToken: required("WEBHOOK_VERIFY_TOKEN"),
  igAccessToken: required("IG_ACCESS_TOKEN"),
  igBusinessAccountId: required("IG_BUSINESS_ACCOUNT_ID"),
  graphApiVersion: "v22.0",
};
