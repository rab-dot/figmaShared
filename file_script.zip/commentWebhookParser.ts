import { IncomingComment, MetaWebhookBody } from "./types";

/**
 * Достаёт из сырого payload'а Meta все комментарии, пришедшие в этом событии.
 * Один webhook-запрос может содержать несколько entry и несколько changes внутри каждого.
 */
export function extractComments(body: MetaWebhookBody): IncomingComment[] {
  const result: IncomingComment[] = [];

  if (body.object !== "instagram") return result;

  for (const entry of body.entry ?? []) {
    for (const change of entry.changes ?? []) {
      if (change.field !== "comments") continue;

      const value = change.value;
      if (!value?.id || !value.text || !value.from?.id || !value.media?.id) {
        // Неполные данные — пропускаем, но не роняем весь запрос
        continue;
      }

      result.push({
        commentId: value.id,
        mediaId: value.media.id,
        text: value.text,
        fromUserId: value.from.id,
        fromUsername: value.from.username,
      });
    }
  }

  return result;
}
