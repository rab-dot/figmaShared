import { Router, Request, Response } from "express";
import { prisma } from "./db";

export const rulesRouter = Router();

/**
 * На Этапе 2 аутентификации пользователей ещё нет, поэтому igAccountId
 * передаём явно в query/body. На Этапе 3 (когда появится auth) это будет
 * браться из сессии/JWT текущего пользователя, а не из параметров запроса.
 */

// GET /api/rules?igAccountId=xxx — список правил аккаунта
rulesRouter.get("/", async (req: Request, res: Response) => {
  const igAccountId = req.query.igAccountId as string | undefined;
  if (!igAccountId) {
    res.status(400).json({ error: "igAccountId обязателен в query" });
    return;
  }

  const rules = await prisma.rule.findMany({
    where: { igAccountId },
    orderBy: { priority: "asc" },
  });
  res.json(rules);
});

// POST /api/rules — создать правило
rulesRouter.post("/", async (req: Request, res: Response) => {
  const { igAccountId, name, keywords, matchType, reply, priority, enabled } = req.body;

  if (!igAccountId || !name || !reply) {
    res.status(400).json({ error: "Обязательные поля: igAccountId, name, reply" });
    return;
  }

  if (matchType && !["CONTAINS", "ANY"].includes(matchType)) {
    res.status(400).json({ error: "matchType должен быть CONTAINS или ANY" });
    return;
  }

  const rule = await prisma.rule.create({
    data: {
      igAccountId,
      name,
      keywords: keywords ?? "",
      matchType: matchType ?? "CONTAINS",
      reply,
      priority: priority ?? 0,
      enabled: enabled ?? true,
    },
  });

  res.status(201).json(rule);
});

// PUT /api/rules/:id — обновить правило
rulesRouter.put("/:id", async (req: Request, res: Response) => {
  const { id } = req.params;
  const { name, keywords, matchType, reply, priority, enabled } = req.body;

  try {
    const rule = await prisma.rule.update({
      where: { id },
      data: {
        ...(name !== undefined && { name }),
        ...(keywords !== undefined && { keywords }),
        ...(matchType !== undefined && { matchType }),
        ...(reply !== undefined && { reply }),
        ...(priority !== undefined && { priority }),
        ...(enabled !== undefined && { enabled }),
      },
    });
    res.json(rule);
  } catch {
    res.status(404).json({ error: "Правило не найдено" });
  }
});

// DELETE /api/rules/:id — удалить правило
rulesRouter.delete("/:id", async (req: Request, res: Response) => {
  const { id } = req.params;

  try {
    await prisma.rule.delete({ where: { id } });
    res.sendStatus(204);
  } catch {
    res.status(404).json({ error: "Правило не найдено" });
  }
});
