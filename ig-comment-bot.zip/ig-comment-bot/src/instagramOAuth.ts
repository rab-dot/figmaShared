import axios from "axios";
import { config } from "./config";

const GRAPH_URL = `https://graph.facebook.com/${config.graphApiVersion}`;

/**
 * Права, которые запрашиваем у пользователя. instagram_business_basic и остальные —
 * это набор для Instagram API with Instagram Login / Facebook Login for Business.
 * Состав может отличаться в зависимости от того, как настроен Use Case в App Dashboard —
 * сверьтесь с актуальным списком в разделе "Permissions and Features" вашего приложения.
 */
const OAUTH_SCOPES = [
  "instagram_basic",
  "instagram_manage_comments",
  "instagram_manage_messages",
  "pages_show_list",
  "pages_read_engagement",
].join(",");

/** Ссылка, на которую нужно отправить пользователя для начала авторизации */
export function buildAuthUrl(state: string): string {
  const url = new URL(`https://www.facebook.com/${config.graphApiVersion}/dialog/oauth`);
  url.searchParams.set("client_id", config.appId);
  url.searchParams.set("redirect_uri", config.oauthRedirectUri);
  url.searchParams.set("scope", OAUTH_SCOPES);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("state", state);
  return url.toString();
}

interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in?: number; // в секундах
}

/** Шаг 1: меняем authorization code на short-lived user access token */
async function exchangeCodeForShortLivedToken(code: string): Promise<string> {
  const { data } = await axios.get<TokenResponse>(`${GRAPH_URL}/oauth/access_token`, {
    params: {
      client_id: config.appId,
      client_secret: config.appSecret,
      redirect_uri: config.oauthRedirectUri,
      code,
    },
  });
  return data.access_token;
}

/** Шаг 2: меняем short-lived токен на long-lived (~60 дней) */
async function exchangeForLongLivedToken(
  shortLivedToken: string
): Promise<{ accessToken: string; expiresInSeconds: number }> {
  const { data } = await axios.get<TokenResponse>(`${GRAPH_URL}/oauth/access_token`, {
    params: {
      grant_type: "fb_exchange_token",
      client_id: config.appId,
      client_secret: config.appSecret,
      fb_exchange_token: shortLivedToken,
    },
  });
  return {
    accessToken: data.access_token,
    expiresInSeconds: data.expires_in ?? 60 * 24 * 60 * 60, // fallback ~60 дней
  };
}

interface PageAccount {
  id: string;
  access_token: string;
  instagram_business_account?: { id: string; username?: string };
}

/**
 * Шаг 3: у пользователя может быть несколько Facebook-страниц — находим ту,
 * к которой привязан Instagram Business аккаунт, и возвращаем её access token
 * (именно page access token используется дальше для вызовов Instagram Graph API,
 * не user access token).
 */
async function findConnectedInstagramAccount(
  longLivedUserToken: string
): Promise<{ igBusinessAccountId: string; username?: string; pageAccessToken: string } | null> {
  const { data } = await axios.get<{ data: PageAccount[] }>(`${GRAPH_URL}/me/accounts`, {
    params: {
      fields: "id,access_token,instagram_business_account{id,username}",
      access_token: longLivedUserToken,
    },
  });

  const pageWithInstagram = data.data.find((page) => page.instagram_business_account);
  if (!pageWithInstagram?.instagram_business_account) return null;

  return {
    igBusinessAccountId: pageWithInstagram.instagram_business_account.id,
    username: pageWithInstagram.instagram_business_account.username,
    pageAccessToken: pageWithInstagram.access_token,
  };
}

export interface OAuthResult {
  igBusinessAccountId: string;
  username?: string;
  accessToken: string;
  expiresAt: Date;
}

/**
 * Полный флоу: code → short-lived → long-lived user token → page token
 * привязанной к Instagram страницы. Именно page token долгоживущий и его
 * стоит хранить — он не истекает вместе с user-сессией.
 */
export async function completeOAuthFlow(code: string): Promise<OAuthResult> {
  const shortLivedToken = await exchangeCodeForShortLivedToken(code);
  const { accessToken: longLivedUserToken, expiresInSeconds } =
    await exchangeForLongLivedToken(shortLivedToken);

  const connected = await findConnectedInstagramAccount(longLivedUserToken);
  if (!connected) {
    throw new Error(
      "Не найдена Facebook-страница с привязанным Instagram Business аккаунтом. " +
        "Проверьте, что аккаунт переведён в Professional и привязан к странице."
    );
  }

  return {
    igBusinessAccountId: connected.igBusinessAccountId,
    username: connected.username,
    accessToken: connected.pageAccessToken,
    expiresAt: new Date(Date.now() + expiresInSeconds * 1000),
  };
}

/**
 * ВАЖНЫЙ НЮАНС: page access token, полученный из long-lived user token, формально
 * "не истекает" (Meta не проставляет ему expires_in) — но может быть инвалидирован,
 * если пользователь сменит пароль Facebook или отзовёт доступ приложению. Поэтому
 * реального "продления" тут нет в классическом OAuth-смысле — единственный надёжный
 * способ проверить, жив ли токен, это периодически дёргать debug_token и, если токен
 * невалиден, просить пользователя заново пройти /auth/instagram.
 * Ниже — best-effort попытка обменять токен на новый через тот же эндпоинт: иногда
 * это продлевает срок, но полагаться только на неё нельзя, поэтому tokenRefreshJob.ts
 * дополнительно логирует и помечает аккаунты с истёкшим токеном для повторного логина.
 */
export async function refreshLongLivedToken(
  currentToken: string
): Promise<{ accessToken: string; expiresAt: Date }> {
  const { accessToken, expiresInSeconds } = await exchangeForLongLivedToken(currentToken);
  return { accessToken, expiresAt: new Date(Date.now() + expiresInSeconds * 1000) };
}

/** Проверяет, действителен ли токен ещё, через официальный debug_token эндпоинт */
export async function isTokenValid(token: string): Promise<boolean> {
  try {
    const { data } = await axios.get<{ data: { is_valid: boolean } }>(`${GRAPH_URL}/debug_token`, {
      params: {
        input_token: token,
        access_token: `${config.appId}|${config.appSecret}`, // app access token
      },
    });
    return data.data.is_valid;
  } catch {
    return false;
  }
}
