import { Router, Request, Response } from "express";
import crypto from "node:crypto";
import { buildAuthUrl, completeOAuthFlow } from "./instagramOAuth";
import { prisma } from "./db";

export const authRouter = Router();

// В памяти процесса, чтобы проверить, что callback пришёл в ответ на наш же редирект
// (защита от CSRF в OAuth-флоу). На нескольких инстансах сервера это нужно вынести в Redis.
const pendingStates = new Set<string>();

// GET /auth/instagram — отправляет пользователя на страницу авторизации Meta
authRouter.get("/instagram", (_req: Request, res: Response) => {
  const state = crypto.randomBytes(16).toString("hex");
  pendingStates.add(state);
  // на всякий случай не даём set расти бесконечно, если callback так и не пришёл
  setTimeout(() => pendingStates.delete(state), 10 * 60 * 1000).unref();

  res.redirect(buildAuthUrl(state));
});

// GET /auth/instagram/callback — сюда Meta возвращает пользователя после авторизации
authRouter.get("/instagram/callback", async (req: Request, res: Response) => {
  const { code, state, error, error_description } = req.query as Record<string, string | undefined>;

  if (error) {
    console.error(`[oauth] Пользователь отклонил авторизацию: ${error} — ${error_description}`);
    res.status(400).send(`Авторизация отменена: ${error_description ?? error}`);
    return;
  }

  if (!code || !state || !pendingStates.has(state)) {
    res.status(400).send("Некорректный или устаревший запрос авторизации, попробуйте ещё раз");
    return;
  }
  pendingStates.delete(state);

  try {
    const result = await completeOAuthFlow(code);

    const account = await prisma.igAccount.upsert({
      where: { igBusinessAccountId: result.igBusinessAccountId },
      update: {
        accessToken: result.accessToken,
        tokenExpiresAt: result.expiresAt,
        username: result.username,
      },
      create: {
        igBusinessAccountId: result.igBusinessAccountId,
        accessToken: result.accessToken,
        tokenExpiresAt: result.expiresAt,
        username: result.username,
      },
    });

    console.log(`[oauth] ✅ Подключён аккаунт @${account.username ?? account.igBusinessAccountId}`);

    // На Этапе с фронтендом тут будет редирект на страницу приложения ("Аккаунт подключён").
    // Пока просто отдаём текстовое подтверждение.
    res.send(
      `✅ Instagram-аккаунт @${account.username ?? account.igBusinessAccountId} успешно подключён. ` +
        `Внутренний id для API: ${account.id}`
    );
  } catch (err) {
    console.error("[oauth] Ошибка при обмене токена:", err);
    res.status(500).send("Не удалось завершить подключение аккаунта, подробности в логах сервера");
  }
});
