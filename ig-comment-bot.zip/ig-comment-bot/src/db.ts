import { PrismaClient } from "@prisma/client";

// Единый инстанс на всё приложение, чтобы не плодить лишние подключения к БД
export const prisma = new PrismaClient();
