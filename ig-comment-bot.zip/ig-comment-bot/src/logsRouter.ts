import { Router, Request, Response } from "express";
import { prisma } from "./db";

export const logsRouter = Router();

// GET /api/logs?igAccountId=xxx&limit=50 — последние отправленные (или неудавшиеся) ответы
logsRouter.get("/", async (req: Request, res: Response) => {
  const igAccountId = req.query.igAccountId as string | undefined;
  const limit = Math.min(Number(req.query.limit ?? 50), 200);

  if (!igAccountId) {
    res.status(400).json({ error: "igAccountId обязателен в query" });
    return;
  }

  const logs = await prisma.sentReply.findMany({
    where: { igAccountId },
    orderBy: { createdAt: "desc" },
    take: limit,
    include: { rule: { select: { name: true } } },
  });

  res.json(logs);
});

// GET /api/logs/stats?igAccountId=xxx — сводка: сколько отправлено/упало, по каким правилам
logsRouter.get("/stats", async (req: Request, res: Response) => {
  const igAccountId = req.query.igAccountId as string | undefined;
  if (!igAccountId) {
    res.status(400).json({ error: "igAccountId обязателен в query" });
    return;
  }

  const [sent, failed, byRule] = await Promise.all([
    prisma.sentReply.count({ where: { igAccountId, status: "SENT" } }),
    prisma.sentReply.count({ where: { igAccountId, status: "FAILED" } }),
    prisma.sentReply.groupBy({
      by: ["ruleId"],
      where: { igAccountId, status: "SENT" },
      _count: { ruleId: true },
    }),
  ]);

  res.json({ sent, failed, byRule });
});
