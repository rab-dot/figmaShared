export interface Rule {
  id: string;
  /** Список ключевых слов (регистронезависимо) */
  keywords: string[];
  /** "contains" — сработает, если в комментарии есть хотя бы одно слово; "any" — сработает на любой комментарий */
  matchType: "contains" | "any";
  /** Текст, который уйдёт в директ комментатору */
  reply: string;
  enabled?: boolean;
}

/** Минимальный набор полей комментария из вебхука Meta, которые нам реально нужны */
export interface IncomingComment {
  commentId: string;
  mediaId: string;
  text: string;
  fromUserId: string;
  fromUsername?: string;
}

/** Задача в очереди на обработку одного комментария конкретного аккаунта */
export interface CommentJobData {
  igAccountId: string;
  comment: IncomingComment;
}
/**
 * Форма payload'а, который присылает Meta на webhook при событии комментария.
 * Реальная структура вложенная (entry[].changes[].value), см. commentWebhookParser.ts
 */
export interface MetaWebhookEntry {
  id: string;
  time: number;
  changes: Array<{
    field: string;
    value: {
      id?: string;
      text?: string;
      media?: { id: string };
      from?: { id: string; username?: string };
    };
  }>;
}

export interface MetaWebhookBody {
  object: string;
  entry: MetaWebhookEntry[];
}
