import express, { Request, Response } from "express";
import cors from "cors";
import { config } from "./config";
import { verifyMetaSignature } from "./verifySignature";
import { extractComments } from "./commentWebhookParser";
import { prisma } from "./db";
import { rulesRouter } from "./rulesRouter";
import { logsRouter } from "./logsRouter";
import { authRouter } from "./authRouter";
import { commentQueue, commentJobId } from "./queue";
import { MetaWebhookBody } from "./types";

const app = express();

// Фронтенд на Vite (localhost:5173 в дев-режиме) обращается к API с другого порта/домена
app.use(cors());

// Сырое тело нужно только для /webhook (проверка подписи), поэтому вешаем verify
// точечно, а не глобально — остальные роуты получают обычный распарсенный JSON.
app.use(
  express.json({
    verify: (req, _res, buf) => {
      (req as Request & { rawBody: Buffer }).rawBody = buf;
    },
  })
);

app.use("/api/rules", rulesRouter);
app.use("/api/logs", logsRouter);
app.use("/auth", authRouter);

/**
 * GET-эндпоинт для верификации вебхука при настройке в Meta App Dashboard.
 */
app.get("/webhook", (req: Request, res: Response) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === config.verifyToken) {
    console.log("[webhook] Верификация прошла успешно");
    res.status(200).send(challenge);
    return;
  }

  console.warn("[webhook] Верификация не пройдена: неверный token или mode");
  res.sendStatus(403);
});

/**
 * POST-эндпоинт, на который Meta шлёт реальные события (новые комментарии и т.д.)
 */
app.post("/webhook", async (req: Request, res: Response) => {
  const rawBody = (req as Request & { rawBody: Buffer }).rawBody;
  const signature = req.header("x-hub-signature-256") ?? undefined;

  if (!verifyMetaSignature(rawBody, signature)) {
    console.warn("[webhook] Невалидная подпись запроса — отклонено");
    res.sendStatus(401);
    return;
  }

  // Отвечаем Meta сразу 200, чтобы она не считала доставку неуспешной и не ретраила.
  // Тяжёлую работу (matching + отправку) делает отдельный процесс — worker.ts.
  res.sendStatus(200);

  const body = req.body as MetaWebhookBody;

  for (const entry of body.entry ?? []) {
    // entry.id — это ig-user-id аккаунта, на который пришло событие
    const igAccount = await prisma.igAccount.findUnique({
      where: { igBusinessAccountId: entry.id },
    });

    if (!igAccount) {
      console.warn(`[webhook] Событие для неизвестного аккаунта ${entry.id}, пропускаем`);
      continue;
    }

    const comments = extractComments({ object: body.object, entry: [entry] });

    for (const comment of comments) {
      console.log(`[webhook] @${comment.fromUsername ?? comment.fromUserId}: "${comment.text}" → в очередь`);

      await commentQueue.add(
        "process-comment",
        { igAccountId: igAccount.id, comment },
        { jobId: commentJobId(igAccount.id, comment.commentId) }
      );
    }
  }
});

app.listen(config.port, () => {
  console.log(`🚀 Сервер запущен на http://localhost:${config.port}`);
  console.log(`   Webhook endpoint: http://localhost:${config.port}/webhook`);
  console.log(`   API правил:       http://localhost:${config.port}/api/rules`);
  console.log(`   API логов:        http://localhost:${config.port}/api/logs`);
  console.log(`   Подключить IG:    http://localhost:${config.port}/auth/instagram`);
  console.log(`   ⚠️  Не забудьте запустить воркер отдельно: npm run worker`);
});
