import axios from "axios";
import { config } from "./config";
import { prisma } from "./db";
import { IncomingComment } from "./types";
import { Rule as PrismaRule } from "@prisma/client";

/**
 * Private Reply — единственный способ Meta официально написать пользователю в Direct
 * "в ответ" на его комментарий, без обычной переписки. Работает ограниченное время
 * после самого комментария (около 7 дней), после чего Meta вернёт ошибку.
 *
 * Документация: POST /{ig-user-id}/messages с recipient.comment_id
 */
export async function sendPrivateReply(params: {
  igAccountId: string; // внутренний id записи IgAccount в нашей БД
  igBusinessAccountId: string; // ig-user-id для вызова Graph API
  accessToken: string;
  comment: IncomingComment;
  rule: PrismaRule;
}): Promise<void> {
  const { igAccountId, igBusinessAccountId, accessToken, comment, rule } = params;
  const url = `https://graph.facebook.com/${config.graphApiVersion}/${igBusinessAccountId}/messages`;

  try {
    await axios.post(
      url,
      {
        recipient: { comment_id: comment.commentId },
        message: { text: rule.reply },
      },
      { params: { access_token: accessToken } }
    );

    console.log(`[privateReply] Отправлено в ответ на комментарий ${comment.commentId}`);

    await prisma.sentReply.create({
      data: {
        igAccountId,
        ruleId: rule.id,
        commentId: comment.commentId,
        fromUserId: comment.fromUserId,
        fromUsername: comment.fromUsername,
        commentText: comment.text,
        replyText: rule.reply,
        status: "SENT",
      },
    });
  } catch (err) {
    const errorMessage = axios.isAxiosError(err)
      ? JSON.stringify(err.response?.data ?? err.message)
      : String(err);

    console.error(`[privateReply] Ошибка отправки для комментария ${comment.commentId}:`, errorMessage);

    // Записываем и неудачную попытку — пригодится для статистики и ретраев на будущем этапе
    await prisma.sentReply
      .create({
        data: {
          igAccountId,
          ruleId: rule.id,
          commentId: comment.commentId,
          fromUserId: comment.fromUserId,
          fromUsername: comment.fromUsername,
          commentText: comment.text,
          replyText: rule.reply,
          status: "FAILED",
          errorMessage,
        },
      })
      .catch((dbErr) => console.error("[privateReply] Не удалось записать лог ошибки:", dbErr));
  }
}
