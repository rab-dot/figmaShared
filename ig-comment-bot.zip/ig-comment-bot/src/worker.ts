import { Worker, Job } from "bullmq";
import { QUEUE_NAME, redisConnection } from "./queue";
import { CommentJobData } from "./types";
import { prisma } from "./db";
import { loadEnabledRules, matchRule } from "./ruleMatcher";
import { sendPrivateReply } from "./privateReply";
import { startTokenRefreshJob } from "./tokenRefreshJob";

async function processJob(job: Job<CommentJobData>): Promise<void> {
  const { igAccountId, comment } = job.data;

  // Анти-дубль на уровне БД — на случай, если очередь всё же получила задачу дважды
  // (например, из-за ретрая Meta до дедупликации по jobId)
  const alreadySent = await prisma.sentReply.findUnique({
    where: { igAccountId_commentId: { igAccountId, commentId: comment.commentId } },
  });
  if (alreadySent) {
    console.log(`[worker] Комментарий ${comment.commentId} уже обработан, пропускаем`);
    return;
  }

  const igAccount = await prisma.igAccount.findUnique({ where: { id: igAccountId } });
  if (!igAccount) {
    console.warn(`[worker] Аккаунт ${igAccountId} не найден, пропускаем задачу`);
    return;
  }

  const rules = await loadEnabledRules(igAccountId);
  const rule = matchRule(comment.text, rules);

  if (!rule) {
    console.log(`[worker] Правило для комментария ${comment.commentId} не найдено`);
    return;
  }

  console.log(`[worker] Совпало правило "${rule.name}" для комментария ${comment.commentId}`);

  await sendPrivateReply({
    igAccountId,
    igBusinessAccountId: igAccount.igBusinessAccountId,
    accessToken: igAccount.accessToken,
    comment,
    rule,
  });
}

const worker = new Worker<CommentJobData>(QUEUE_NAME, processJob, {
  connection: redisConnection,
  concurrency: 5,
});

worker.on("completed", (job) => {
  console.log(`[worker] ✅ Задача ${job.id} выполнена`);
});

worker.on("failed", (job, err) => {
  console.error(`[worker] ❌ Задача ${job?.id} упала (попытка ${job?.attemptsMade}):`, err.message);
});

console.log("👷 Воркер очереди комментариев запущен");

startTokenRefreshJob();
console.log("🔑 Фоновая проверка токенов запущена (раз в сутки)");

process.on("SIGTERM", async () => {
  await worker.close();
  process.exit(0);
});
