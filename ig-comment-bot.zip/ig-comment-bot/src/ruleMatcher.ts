import { Rule as PrismaRule } from "@prisma/client";
import { prisma } from "./db";

export async function loadEnabledRules(igAccountId: string): Promise<PrismaRule[]> {
  return prisma.rule.findMany({
    where: { igAccountId, enabled: true },
    orderBy: { priority: "asc" },
  });
}

/** Возвращает первое подходящее правило, либо null */
export function matchRule(commentText: string, rules: PrismaRule[]): PrismaRule | null {
  const normalized = commentText.toLowerCase();

  for (const rule of rules) {
    if (rule.matchType === "ANY") {
      return rule;
    }

    const keywords = rule.keywords
      .split(",")
      .map((k) => k.trim().toLowerCase())
      .filter(Boolean);

    const hit = keywords.some((kw) => normalized.includes(kw));
    if (hit) return rule;
  }

  return null;
}
