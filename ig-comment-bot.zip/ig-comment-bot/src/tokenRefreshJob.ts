import { prisma } from "./db";
import { isTokenValid, refreshLongLivedToken } from "./instagramOAuth";

const CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000; // раз в сутки
const REFRESH_WINDOW_DAYS = 10; // начинаем беспокоиться за 10 дней до истечения

/** Проверяет все аккаунты и пытается продлить токены, которые скоро истекут */
export async function refreshExpiringTokens(): Promise<void> {
  const soon = new Date(Date.now() + REFRESH_WINDOW_DAYS * 24 * 60 * 60 * 1000);

  const accounts = await prisma.igAccount.findMany({
    where: {
      OR: [{ tokenExpiresAt: { lte: soon } }, { tokenExpiresAt: null }],
    },
  });

  if (accounts.length === 0) {
    console.log("[tokenRefresh] Нет аккаунтов, требующих внимания");
    return;
  }

  for (const account of accounts) {
    const valid = await isTokenValid(account.accessToken);

    if (!valid) {
      console.error(
        `[tokenRefresh] ❌ Токен аккаунта @${account.username ?? account.igBusinessAccountId} ` +
          `невалиден — нужен повторный вход через /auth/instagram`
      );
      // Здесь на будущем этапе стоит слать уведомление (email/telegram),
      // чтобы не узнать о протухшем токене только по факту переставших отправляться сообщений.
      continue;
    }

    try {
      const { accessToken, expiresAt } = await refreshLongLivedToken(account.accessToken);
      await prisma.igAccount.update({
        where: { id: account.id },
        data: { accessToken, tokenExpiresAt: expiresAt },
      });
      console.log(
        `[tokenRefresh] ✅ Токен @${account.username ?? account.igBusinessAccountId} продлён до ${expiresAt.toISOString()}`
      );
    } catch (err) {
      console.error(`[tokenRefresh] Не удалось продлить токен для ${account.id}:`, err);
    }
  }
}

/** Запускает периодическую проверку — вызывается один раз при старте worker.ts */
export function startTokenRefreshJob(): void {
  refreshExpiringTokens().catch((err) => console.error("[tokenRefresh] Ошибка первого прогона:", err));
  setInterval(() => {
    refreshExpiringTokens().catch((err) => console.error("[tokenRefresh] Ошибка прогона:", err));
  }, CHECK_INTERVAL_MS).unref();
}
