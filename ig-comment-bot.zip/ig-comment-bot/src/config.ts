import "dotenv/config";

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Отсутствует обязательная переменная окружения: ${name}`);
  }
  return value;
}

export const config = {
  port: Number(process.env.PORT ?? 3000),
  appId: required("META_APP_ID"),
  appSecret: required("META_APP_SECRET"),
  verifyToken: required("WEBHOOK_VERIFY_TOKEN"),
  redisUrl: required("REDIS_URL"),
  oauthRedirectUri: required("OAUTH_REDIRECT_URI"),
  graphApiVersion: "v22.0",
};
