import { Queue } from "bullmq";
import IORedis from "ioredis";
import { config } from "./config";
import { CommentJobData } from "./types";

export const QUEUE_NAME = "comment-replies";

/**
 * BullMQ требует maxRetriesPerRequest: null для корректной работы блокирующих
 * команд (используется внутри Worker'а под капотом).
 */
export const redisConnection = new IORedis(config.redisUrl, {
  maxRetriesPerRequest: null,
});

export const commentQueue = new Queue<CommentJobData>(QUEUE_NAME, {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: "exponential", delay: 5000 },
    removeOnComplete: { age: 60 * 60 * 24 }, // хранить выполненные задачи сутки
    removeOnFail: { age: 60 * 60 * 24 * 7 }, // упавшие — неделю, для разбора причин
  },
});

/**
 * jobId делаем детерминированным (igAccountId + commentId), чтобы BullMQ сам
 * не дал добавить в очередь два одинаковых события — это защита от дублей
 * ещё до похода в БД (Meta иногда шлёт повторные вебхуки при нестабильной сети).
 */
export function commentJobId(igAccountId: string, commentId: string): string {
  return `${igAccountId}:${commentId}`;
}
