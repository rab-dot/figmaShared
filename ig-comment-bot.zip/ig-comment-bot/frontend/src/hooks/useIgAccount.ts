import { useCallback, useState } from "react";

const STORAGE_KEY = "ig-comment-bot:igAccountId";

/**
 * Пока на бэкенде нет полноценной авторизации пользователей, id подключённого
 * IG-аккаунта хранится в localStorage браузера — его нужно один раз вставить
 * после прохождения /auth/instagram (см. ConnectAccount.tsx).
 * Когда на бэкенде появится auth, это заменится на чтение из сессии/JWT.
 */
export function useIgAccount() {
  const [igAccountId, setIgAccountIdState] = useState<string | null>(() =>
    localStorage.getItem(STORAGE_KEY)
  );

  const setIgAccountId = useCallback((value: string | null) => {
    if (value) {
      localStorage.setItem(STORAGE_KEY, value);
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
    setIgAccountIdState(value);
  }, []);

  return { igAccountId, setIgAccountId };
}
