import { useEffect, useState } from "react";
import { useIgAccount } from "./hooks/useIgAccount";
import { api } from "./api";
import type { Stats } from "./types";
import { ConnectAccount } from "./components/ConnectAccount";
import { StatsCards } from "./components/StatsCards";
import { RulesPanel } from "./components/RulesPanel";
import { LogsPanel } from "./components/LogsPanel";
import { PipelineMark } from "./components/PipelineMark";

type Tab = "rules" | "logs";

export default function App() {
  const { igAccountId, setIgAccountId } = useIgAccount();
  const [tab, setTab] = useState<Tab>("rules");
  const [stats, setStats] = useState<Stats | null>(null);
  const [statsLoading, setStatsLoading] = useState(true);

  useEffect(() => {
    if (!igAccountId) return;
    setStatsLoading(true);
    api.logs
      .stats(igAccountId)
      .then(setStats)
      .finally(() => setStatsLoading(false));
  }, [igAccountId, tab]);

  if (!igAccountId) {
    return <ConnectAccount onConnect={setIgAccountId} />;
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div className="topbar__brand">
          <PipelineMark />
          <span>Автоответчик комментариев</span>
        </div>
        <button className="btn btn-ghost" onClick={() => setIgAccountId(null)}>
          Отключить аккаунт
        </button>
      </header>

      <main className="content">
        <StatsCards stats={stats} loading={statsLoading} />

        <nav className="tabs">
          <button
            className={`tab ${tab === "rules" ? "tab--active" : ""}`}
            onClick={() => setTab("rules")}
          >
            Правила
          </button>
          <button
            className={`tab ${tab === "logs" ? "tab--active" : ""}`}
            onClick={() => setTab("logs")}
          >
            Активность
          </button>
        </nav>

        <section className="panel">
          {tab === "rules" ? (
            <RulesPanel igAccountId={igAccountId} />
          ) : (
            <LogsPanel igAccountId={igAccountId} />
          )}
        </section>
      </main>
    </div>
  );
}
