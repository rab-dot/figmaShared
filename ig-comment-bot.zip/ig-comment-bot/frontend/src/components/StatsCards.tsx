import type { Stats } from "../types";

interface Props {
  stats: Stats | null;
  loading: boolean;
}

export function StatsCards({ stats, loading }: Props) {
  const items = [
    { label: "Отправлено в директ", value: stats?.sent, tone: "success" as const },
    { label: "Не удалось отправить", value: stats?.failed, tone: "danger" as const },
    {
      label: "Активных правил сработало",
      value: stats?.byRule.length,
      tone: "neutral" as const,
    },
  ];

  return (
    <div className="stats-row">
      {items.map((item) => (
        <div key={item.label} className={`stats-card stats-card--${item.tone}`}>
          <span className="stats-card__value mono">{loading ? "—" : (item.value ?? 0)}</span>
          <span className="stats-card__label">{item.label}</span>
        </div>
      ))}
    </div>
  );
}
