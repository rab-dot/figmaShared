interface Props {
  size?: number;
}

/**
 * Сигнатурный элемент интерфейса: пузырь комментария перетекает в пузырь директа.
 * Используется как лого в шапке и в пустых состояниях.
 */
export function PipelineMark({ size = 28 }: Props) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path
        d="M4 8.5C4 6.567 5.567 5 7.5 5H15.5C17.433 5 19 6.567 19 8.5V13.5C19 15.433 17.433 17 15.5 17H10L6 20.5V17H7.5C5.567 17 4 15.433 4 13.5V8.5Z"
        fill="var(--indigo)"
      />
      <path
        d="M13 18.5C13 16.567 14.567 15 16.5 15H24.5C26.433 15 28 16.567 28 18.5V23.5C28 25.433 26.433 27 24.5 27H23V30L19 27H16.5C14.567 27 13 25.433 13 23.5V18.5Z"
        fill="var(--accent)"
      />
    </svg>
  );
}
