import { useEffect, useState } from "react";
import { api } from "../api";
import type { SentReply } from "../types";
import { PipelineMark } from "./PipelineMark";

interface Props {
  igAccountId: string;
}

function formatTime(iso: string): string {
  return new Date(iso).toLocaleString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function LogsPanel({ igAccountId }: Props) {
  const [logs, setLogs] = useState<SentReply[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.logs
      .list(igAccountId, 50)
      .then(setLogs)
      .finally(() => setLoading(false));
  }, [igAccountId]);

  if (loading) return <p className="muted">Загружаю журнал…</p>;

  if (logs.length === 0) {
    return (
      <div className="empty-state">
        <PipelineMark size={32} />
        <p>Пока ни одного комментария не обработано. Как только придёт новый — он появится здесь.</p>
      </div>
    );
  }

  return (
    <div className="logs-table-wrap">
      <table className="logs-table">
        <thead>
          <tr>
            <th>Когда</th>
            <th>От кого</th>
            <th>Комментарий</th>
            <th>Правило</th>
            <th>Статус</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log) => (
            <tr key={log.id}>
              <td className="mono muted">{formatTime(log.createdAt)}</td>
              <td>@{log.fromUsername ?? log.fromUserId}</td>
              <td className="logs-table__comment" title={log.commentText}>
                {log.commentText}
              </td>
              <td>{log.rule?.name ?? "—"}</td>
              <td>
                <span
                  className={`badge ${log.status === "SENT" ? "badge--on" : "badge--danger"}`}
                  title={log.errorMessage ?? undefined}
                >
                  {log.status === "SENT" ? "отправлено" : "ошибка"}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
