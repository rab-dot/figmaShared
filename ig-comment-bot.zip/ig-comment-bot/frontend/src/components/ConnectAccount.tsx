import { useState } from "react";
import { api } from "../api";
import { PipelineMark } from "./PipelineMark";

interface Props {
  onConnect: (igAccountId: string) => void;
}

export function ConnectAccount({ onConnect }: Props) {
  const [manualId, setManualId] = useState("");

  return (
    <div className="connect-screen">
      <div className="connect-card">
        <PipelineMark size={36} />
        <h1>Подключите Instagram</h1>
        <p className="connect-lead">
          Авторизуйтесь через Meta — это откроет страницу входа Facebook/Instagram
          и после подтверждения вернёт вас с готовым id аккаунта.
        </p>
        <a className="btn btn-accent" href={api.authUrl()}>
          Войти через Instagram
        </a>

        <div className="connect-divider">
          <span>или вставьте id вручную</span>
        </div>

        <p className="connect-hint">
          После авторизации сервер покажет строку вида «Внутренний id для API: …» —
          скопируйте её сюда.
        </p>
        <form
          className="connect-form"
          onSubmit={(e) => {
            e.preventDefault();
            if (manualId.trim()) onConnect(manualId.trim());
          }}
        >
          <input
            className="input mono"
            placeholder="clxxxxxxxxxxxxxxxxxxxx"
            value={manualId}
            onChange={(e) => setManualId(e.target.value)}
          />
          <button className="btn btn-secondary" type="submit" disabled={!manualId.trim()}>
            Использовать
          </button>
        </form>
      </div>
    </div>
  );
}
