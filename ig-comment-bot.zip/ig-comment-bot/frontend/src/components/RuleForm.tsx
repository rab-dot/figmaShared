import { useState } from "react";
import type { FormEvent } from "react";
import type { MatchType, Rule, RuleInput } from "../types";

interface Props {
  initial?: Rule;
  onSubmit: (input: RuleInput) => Promise<void>;
  onCancel?: () => void;
}

const EMPTY: RuleInput = {
  name: "",
  keywords: "",
  matchType: "CONTAINS",
  reply: "",
  enabled: true,
  priority: 0,
};

export function RuleForm({ initial, onSubmit, onCancel }: Props) {
  const [form, setForm] = useState<RuleInput>(
    initial
      ? {
          name: initial.name,
          keywords: initial.keywords,
          matchType: initial.matchType,
          reply: initial.reply,
          enabled: initial.enabled,
          priority: initial.priority,
        }
      : EMPTY
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await onSubmit(form);
      if (!initial) setForm(EMPTY);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Не удалось сохранить правило");
    } finally {
      setSaving(false);
    }
  };

  return (
    <form className="rule-form" onSubmit={handleSubmit}>
      <div className="rule-form__row">
        <label className="field">
          <span className="field__label">Название</span>
          <input
            className="input"
            required
            placeholder="Вопрос про цену"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
        </label>

        <label className="field field--narrow">
          <span className="field__label">Условие</span>
          <select
            className="input"
            value={form.matchType}
            onChange={(e) => setForm({ ...form, matchType: e.target.value as MatchType })}
          >
            <option value="CONTAINS">Содержит слово</option>
            <option value="ANY">Любой комментарий</option>
          </select>
        </label>
      </div>

      {form.matchType === "CONTAINS" && (
        <label className="field">
          <span className="field__label">Ключевые слова (через запятую)</span>
          <input
            className="input mono"
            placeholder="цена, стоимость, прайс"
            value={form.keywords}
            onChange={(e) => setForm({ ...form, keywords: e.target.value })}
          />
        </label>
      )}

      <label className="field">
        <span className="field__label">Текст ответа в директ</span>
        <textarea
          className="input"
          required
          rows={3}
          placeholder="Привет! Скинула цену в директ 😊"
          value={form.reply}
          onChange={(e) => setForm({ ...form, reply: e.target.value })}
        />
      </label>

      <div className="rule-form__footer">
        <label className="checkbox">
          <input
            type="checkbox"
            checked={form.enabled}
            onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
          />
          Правило активно
        </label>

        <div className="rule-form__actions">
          {onCancel && (
            <button type="button" className="btn btn-ghost" onClick={onCancel}>
              Отмена
            </button>
          )}
          <button type="submit" className="btn btn-accent" disabled={saving}>
            {saving ? "Сохраняю…" : initial ? "Сохранить" : "Добавить правило"}
          </button>
        </div>
      </div>

      {error && <p className="form-error">{error}</p>}
    </form>
  );
}
