import { useEffect, useState } from "react";
import { api, ApiError } from "../api";
import type { Rule, RuleInput } from "../types";
import { RuleForm } from "./RuleForm";
import { PipelineMark } from "./PipelineMark";

interface Props {
  igAccountId: string;
}

export function RulesPanel({ igAccountId }: Props) {
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showNewForm, setShowNewForm] = useState(false);

  const load = () => {
    setLoading(true);
    api.rules
      .list(igAccountId)
      .then(setRules)
      .catch((err) => setError(err instanceof Error ? err.message : "Ошибка загрузки"))
      .finally(() => setLoading(false));
  };

  useEffect(load, [igAccountId]);

  const handleCreate = async (input: RuleInput) => {
    const created = await api.rules.create(igAccountId, input);
    setRules((prev) => [...prev, created].sort((a, b) => a.priority - b.priority));
    setShowNewForm(false);
  };

  const handleUpdate = async (id: string, input: RuleInput) => {
    const updated = await api.rules.update(id, input);
    setRules((prev) => prev.map((r) => (r.id === id ? updated : r)));
    setEditingId(null);
  };

  const handleToggle = async (rule: Rule) => {
    const updated = await api.rules.update(rule.id, { enabled: !rule.enabled });
    setRules((prev) => prev.map((r) => (r.id === rule.id ? updated : r)));
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Удалить это правило?")) return;
    try {
      await api.rules.remove(id);
      setRules((prev) => prev.filter((r) => r.id !== id));
    } catch (err) {
      alert(err instanceof ApiError ? err.message : "Не удалось удалить правило");
    }
  };

  if (loading) return <p className="muted">Загружаю правила…</p>;
  if (error) return <p className="form-error">{error}</p>;

  return (
    <div className="rules-panel">
      {rules.length === 0 && !showNewForm && (
        <div className="empty-state">
          <PipelineMark size={32} />
          <p>Правил пока нет. Добавьте первое — какое слово в комментарии запускает ответ?</p>
        </div>
      )}

      <ul className="rule-list">
        {rules.map((rule) => (
          <li key={rule.id} className={`rule-card ${rule.enabled ? "" : "rule-card--disabled"}`}>
            {editingId === rule.id ? (
              <RuleForm
                initial={rule}
                onSubmit={(input) => handleUpdate(rule.id, input)}
                onCancel={() => setEditingId(null)}
              />
            ) : (
              <>
                <div className="rule-card__main">
                  <div className="rule-card__title-row">
                    <h3>{rule.name}</h3>
                    <span className={`badge ${rule.enabled ? "badge--on" : "badge--off"}`}>
                      {rule.enabled ? "активно" : "выключено"}
                    </span>
                  </div>
                  <p className="rule-card__condition">
                    {rule.matchType === "ANY" ? (
                      "Срабатывает на любой комментарий"
                    ) : (
                      <>
                        Срабатывает на:{" "}
                        {rule.keywords.split(",").map((kw) => (
                          <code key={kw} className="chip">
                            {kw.trim()}
                          </code>
                        ))}
                      </>
                    )}
                  </p>
                  <p className="rule-card__reply">«{rule.reply}»</p>
                </div>
                <div className="rule-card__actions">
                  <button className="btn btn-ghost" onClick={() => handleToggle(rule)}>
                    {rule.enabled ? "Выключить" : "Включить"}
                  </button>
                  <button className="btn btn-ghost" onClick={() => setEditingId(rule.id)}>
                    Изменить
                  </button>
                  <button className="btn btn-ghost btn-danger" onClick={() => handleDelete(rule.id)}>
                    Удалить
                  </button>
                </div>
              </>
            )}
          </li>
        ))}
      </ul>

      {showNewForm ? (
        <div className="rule-card rule-card--new">
          <RuleForm onSubmit={handleCreate} onCancel={() => setShowNewForm(false)} />
        </div>
      ) : (
        <button className="btn btn-secondary btn-block" onClick={() => setShowNewForm(true)}>
          + Добавить правило
        </button>
      )}
    </div>
  );
}
