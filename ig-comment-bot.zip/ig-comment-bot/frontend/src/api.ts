import type { Rule, RuleInput, SentReply, Stats } from "./types";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3000";

class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new ApiError(body.error ?? `Запрос завершился с ошибкой ${res.status}`, res.status);
  }

  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export const api = {
  authUrl: () => `${API_URL}/auth/instagram`,

  rules: {
    list: (igAccountId: string) =>
      request<Rule[]>(`/api/rules?igAccountId=${encodeURIComponent(igAccountId)}`),

    create: (igAccountId: string, input: RuleInput) =>
      request<Rule>("/api/rules", {
        method: "POST",
        body: JSON.stringify({ igAccountId, ...input }),
      }),

    update: (id: string, input: Partial<RuleInput>) =>
      request<Rule>(`/api/rules/${id}`, {
        method: "PUT",
        body: JSON.stringify(input),
      }),

    remove: (id: string) => request<void>(`/api/rules/${id}`, { method: "DELETE" }),
  },

  logs: {
    list: (igAccountId: string, limit = 50) =>
      request<SentReply[]>(
        `/api/logs?igAccountId=${encodeURIComponent(igAccountId)}&limit=${limit}`
      ),

    stats: (igAccountId: string) =>
      request<Stats>(`/api/logs/stats?igAccountId=${encodeURIComponent(igAccountId)}`),
  },
};

export { ApiError };
