export type MatchType = "CONTAINS" | "ANY";
export type ReplyStatus = "SENT" | "FAILED";

export interface Rule {
  id: string;
  igAccountId: string;
  name: string;
  keywords: string; // через запятую
  matchType: MatchType;
  reply: string;
  enabled: boolean;
  priority: number;
  createdAt: string;
  updatedAt: string;
}

export type RuleInput = Omit<Rule, "id" | "igAccountId" | "createdAt" | "updatedAt">;

export interface SentReply {
  id: string;
  igAccountId: string;
  ruleId: string | null;
  rule: { name: string } | null;
  commentId: string;
  fromUserId: string;
  fromUsername: string | null;
  commentText: string;
  replyText: string;
  status: ReplyStatus;
  errorMessage: string | null;
  createdAt: string;
}

export interface Stats {
  sent: number;
  failed: number;
  byRule: Array<{ ruleId: string | null; _count: { ruleId: number } }>;
}
