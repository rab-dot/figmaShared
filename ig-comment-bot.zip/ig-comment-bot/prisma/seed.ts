import "dotenv/config";
import { prisma } from "../src/db";

/**
 * Seed теперь используется в основном для создания примера правила.
 * Подключение самого IG-аккаунта делается через /auth/instagram (OAuth-флоу),
 * но если по какой-то причине хочется добавить аккаунт вручную (например,
 * тестовый токен без прохождения полного флоу) — можно заполнить
 * IG_ACCESS_TOKEN/IG_BUSINESS_ACCOUNT_ID в .env, тогда seed создаст запись сам.
 * Запуск: npm run db:seed
 */
async function main() {
  const igBusinessAccountId = process.env.IG_BUSINESS_ACCOUNT_ID;
  const accessToken = process.env.IG_ACCESS_TOKEN;

  let account = igBusinessAccountId
    ? await prisma.igAccount.findUnique({ where: { igBusinessAccountId } })
    : null;

  if (!account && igBusinessAccountId && accessToken) {
    account = await prisma.igAccount.create({ data: { igBusinessAccountId, accessToken } });
    console.log(`✅ Создан IgAccount вручную: ${account.id} (${account.igBusinessAccountId})`);
  }

  if (!account) {
    account = await prisma.igAccount.findFirst({ orderBy: { createdAt: "asc" } });
  }

  if (!account) {
    console.log(
      "ℹ️  В базе пока нет ни одного подключённого аккаунта.\n" +
        "   Пройдите авторизацию через http://localhost:3000/auth/instagram, " +
        "либо заполните IG_ACCESS_TOKEN и IG_BUSINESS_ACCOUNT_ID в .env и запустите seed снова."
    );
    return;
  }

  const existingRules = await prisma.rule.count({ where: { igAccountId: account.id } });
  if (existingRules > 0) {
    console.log(`ℹ️  У аккаунта уже есть ${existingRules} правил(a), пропускаем создание примеров`);
    return;
  }

  await prisma.rule.create({
    data: {
      igAccountId: account.id,
      name: "Вопрос про цену",
      keywords: "цена,стоимость,прайс",
      matchType: "CONTAINS",
      reply: "Привет! Скинула цену в директ 😊",
      priority: 0,
    },
  });

  console.log(`✅ Создано стартовое правило-пример для аккаунта ${account.id}`);
}

main()
  .catch((err) => {
    console.error("❌ Ошибка seed:", err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
