# ig-comment-bot — Этап 1 + Этап 2

Сервер, который слушает вебхуки Instagram (Meta Graph API) о новых комментариях,
сверяет текст с правилами из БД и отправляет автоответ в директ через Private Reply API.
Плюс CRUD-эндпоинты для управления правилами — на них будет опираться будущий фронтенд.

## Структура

```
prisma/
  schema.prisma            — модели БД: IgAccount, Rule, SentReply
  seed.ts                   — разовый перенос IG_ACCESS_TOKEN из .env в БД + пример правила
src/
  server.ts                — express-сервер: /webhook, /auth/instagram, /api/rules, /api/logs
  worker.ts                 — отдельный процесс: очередь комментариев + фоновое продление токенов
  authRouter.ts              — OAuth-роуты: инициация авторизации и callback
  instagramOAuth.ts          — обмен code → токен, обмен на long-lived, поиск IG-аккаунта
  tokenRefreshJob.ts         — периодическая проверка и попытка продления токенов
  queue.ts                  — определение очереди BullMQ и подключения к Redis
  db.ts                     — единый инстанс PrismaClient
  config.ts                 — чтение .env
  verifySignature.ts        — проверка HMAC-подписи от Meta
  commentWebhookParser.ts   — разбор payload'а вебхука в удобный формат
  ruleMatcher.ts            — загрузка правил аккаунта из БД + сопоставление с текстом
  privateReply.ts           — отправка сообщения в директ через Graph API + лог в БД
  rulesRouter.ts            — CRUD /api/rules
  logsRouter.ts             — GET /api/logs, /api/logs/stats
  types.ts                  — общие типы
docker-compose.yml          — локальный Postgres + Redis для разработки
```

## Модель данных

- **IgAccount** — подключённый Instagram-аккаунт (ig-user-id + access token). Сейчас один,
  но модель уже готова к нескольким аккаунтам под одним пользователем в будущем.
- **Rule** — правило автоответа, привязано к аккаунту, приоритет определяет порядок проверки.
- **SentReply** — лог каждой попытки отправки (успех/ошибка), с уникальным ограничением
  `(igAccountId, commentId)` — это и есть защита от повторного ответа одному человеку.

## OAuth-флоу подключения аккаунта

Вместо ручного копирования токена из Graph API Explorer, аккаунт подключается через
браузер:

1. Откройте `http://localhost:3000/auth/instagram` — редиректнёт на страницу авторизации Meta.
2. Залогиньтесь и подтвердите запрошенные права.
3. Meta вернёт вас на `/auth/instagram/callback` — сервер сам обменяет `code` на токен,
   найдёт привязанный Instagram Business аккаунт и сохранит всё в таблицу `IgAccount`
   (заодно покажет внутренний `id` аккаунта — он нужен для вызовов `/api/rules` и `/api/logs`).

Что происходит под капотом (см. `instagramOAuth.ts`):
1. `code` → short-lived user access token.
2. short-lived → long-lived user access token (~60 дней).
3. по long-lived user token находим Facebook-страницу с привязанным Instagram Business
   аккаунтом (`/me/accounts`) и берём **page access token** этой страницы — именно он
   используется для вызовов Instagram Graph API и Private Reply, не user-токен.

**Фоновое продление** (`tokenRefreshJob.ts`, запускается вместе с `npm run worker`):
раз в сутки проверяет все аккаунты, чей токен истекает в течение 10 дней, через
`debug_token` эндпоинт. Если токен ещё валиден — пробует продлить, если уже нет —
пишет в лог, что нужен повторный вход через `/auth/instagram` (аккаунт при этом не
удаляется, просто перестаёт получать новые отправки, пока токен не обновят).

⚠️ Важный нюанс: page access token, полученный из long-lived user token, формально
"бессрочный" по данным Meta, но может быть инвалидирован при смене пароля Facebook
или отзыве доступа приложению. Поэтому автоматическое продление — best-effort, а не
железная гарантия; при долгом простое стоит проверить логи воркера на предмет
`[tokenRefresh] ❌`.

## Как работает очередь

`server.ts` при вебхуке только проверяет подпись, находит аккаунт в БД и кладёт задачу
в очередь Redis (BullMQ) — сразу отвечает Meta `200 OK` и не делает ничего тяжёлого.
`worker.ts` — отдельный процесс, который эти задачи забирает, делает matching по
правилам и вызывает Private Reply API.

Зачем разделять:
- если Meta пришлёт пачку комментариев одновременно, вебхук-эндпоинт не тормозит
  и не рискует таймаутом ответа Meta;
- если воркер упадёт или Graph API вернёт ошибку — BullMQ сам retry'ит задачу
  (3 попытки с экспоненциальной задержкой, настроено в `queue.ts`);
- `jobId` формируется как `igAccountId:commentId` (см. `commentJobId`), поэтому даже
  если Meta продублирует вебхук, вторая попытка добавить ту же задачу в очередь
  просто проигнорируется BullMQ.

## Настройка (Meta стороне)

1. Создайте приложение на https://developers.facebook.com/apps → тип "Business".
2. В настройках приложения добавьте себя как **Admin/Tester** (Roles → App roles) —
   это даёт Standard Access без App Review, если использовать только свой аккаунт.
3. Переведите ваш Instagram в **Professional (Business или Creator)** аккаунт
   и привяжите его к Facebook-странице.
4. Добавьте продукт **Facebook Login for Business** (или Instagram Login, в зависимости
   от того, что предлагает Dashboard на момент настройки) → в **Valid OAuth Redirect URIs**
   впишите тот же адрес, что и в `OAUTH_REDIRECT_URI` (например `https://xxxx.ngrok-free.app/auth/instagram/callback`).
5. В продукте **Webhooks** подпишитесь на объект `instagram`, поле `comments`.
6. App ID и App Secret возьмите в Settings → Basic.

Токен для API теперь получать вручную не нужно — этим занимается OAuth-флоу ниже.

## Настройка локально

```bash
cp .env.example .env
# заполните META_APP_ID, META_APP_SECRET, OAUTH_REDIRECT_URI,
# WEBHOOK_VERIFY_TOKEN (придумайте сами), DATABASE_URL, REDIS_URL

npm install

# поднимаем локальный Postgres и Redis (или используйте свои — тогда поправьте .env)
docker compose up -d

# генерируем клиент Prisma и накатываем миграцию
npm run db:generate
npm run db:migrate      # спросит имя миграции, например "init"

# нужны ДВА процесса одновременно, в разных терминалах:
npm run dev       # HTTP-сервер (webhook + OAuth + API)
npm run worker    # обработчик очереди + фоновое продление токенов

# подключаем сам Instagram-аккаунт — откройте в браузере:
# http://localhost:3000/auth/instagram

# опционально: создать пример правила для только что подключённого аккаунта
npm run db:seed
```

Сервер поднимется на `http://localhost:3000`. Посмотреть/поредактировать данные глазами
можно через `npm run db:studio` (откроет Prisma Studio в браузере). Посмотреть состояние
очереди (сколько задач в ожидании/упало) — проще всего через
[Bull Board](https://github.com/felixmosh/bull-board) или Prisma Studio по таблице `SentReply`
(там видны и успешные, и упавшие попытки со статусом `FAILED`).

## Публичный HTTPS для вебхука (локальная разработка)

Meta не примет `http://localhost` — нужен публичный HTTPS-адрес. Проще всего через ngrok:

```bash
ngrok http 3000
```

Скопируйте выданный `https://xxxx.ngrok-free.app` и в Meta App Dashboard → Webhooks
укажите Callback URL: `https://xxxx.ngrok-free.app/webhook`, Verify Token —
тот же, что в `.env` (`WEBHOOK_VERIFY_TOKEN`).

## API для управления правилами

`igAccountId` — это внутренний `id` записи в таблице `IgAccount` (не ig-user-id из Meta),
его можно посмотреть после seed в консоли или через Prisma Studio.

```bash
# Список правил
curl "http://localhost:3000/api/rules?igAccountId=clxxxx"

# Создать правило
curl -X POST http://localhost:3000/api/rules \
  -H "Content-Type: application/json" \
  -d '{
    "igAccountId": "clxxxx",
    "name": "Вопрос про доставку",
    "keywords": "доставка,отправка",
    "matchType": "CONTAINS",
    "reply": "Привет! Все детали по доставке отправила в директ 📦"
  }'

# Обновить (например, отключить)
curl -X PUT http://localhost:3000/api/rules/RULE_ID \
  -H "Content-Type: application/json" \
  -d '{"enabled": false}'

# Удалить
curl -X DELETE http://localhost:3000/api/rules/RULE_ID

# Статистика отправок
curl "http://localhost:3000/api/logs/stats?igAccountId=clxxxx"
```

- `matchType: "CONTAINS"` — сработает, если в комментарии есть хотя бы одно слово из `keywords`
  (через запятую).
- `matchType: "ANY"` — сработает на любой комментарий.
- `priority` — чем меньше число, тем раньше правило проверяется; срабатывает первое подходящее.
- `enabled: false` — правило временно не участвует в проверке.

## Ограничения, которые нужно держать в голове

- **Private Reply работает только ограниченное время** после комментария
  (у Meta это порядка 7 дней) — старые комментарии так не обработать.
- **Rate limits**: у Graph API лимит на количество вызовов в час на пользователя,
  при активном аккаунте это может стать узким местом (см. заголовки ответа API).
- Обработка вебхука и отправка теперь разделены очередью — при падении воркера или сбое
  Graph API задача не теряется и повторится автоматически (см. "Как работает очередь" выше).
  Единственное, что не переживёт падение — сам момент постановки задачи в очередь между
  `res.sendStatus(200)` и `commentQueue.add(...)`; это доля секунды, и в худшем случае
  Meta всё равно попробует передоставить вебхук ещё раз при ошибке.

## Следующие шаги

- Авторизация пользователей — как только появится реальный вход в аккаунт, `igAccountId` в query/body
  API нужно будет заменить на определение аккаунта из сессии/JWT текущего пользователя.
- Уведомления (email/Telegram), если `tokenRefreshJob` обнаружит невалидный токен —
  сейчас это только лог в консоли воркера.
- Bull Board или похожий UI для наблюдения за очередью в проде (сейчас только логи в консоли
  воркера и таблица `SentReply` в БД).

## Фронтенд

Готовый интерфейс на React 19 + TypeScript лежит в соседней папке `frontend/` —
см. `frontend/README.md` для запуска. Он обращается к этому серверу через `/api/rules`,
`/api/logs` и `/auth/instagram`, поэтому запускать нужно оба процесса плюс воркер.
