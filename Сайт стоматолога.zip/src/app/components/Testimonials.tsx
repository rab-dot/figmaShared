import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

export function Testimonials() {
  const testimonials = [
    {
      id: 1,
      name: 'Мария Петрова',
      image:
        'https://images.unsplash.com/photo-1584516150909-c43483ee7932?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHBhdGllbnQlMjB0ZXN0aW1vbmlhbHxlbnwxfHx8fDE3NzU3MTg5MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      rating: 5,
      text: 'Анна Ивановна - настоящий профессионал! Я боялась стоматологов всю жизнь, но здесь все прошло абсолютно безболезненно. Результат превзошел все ожидания!',
      source: 'ПроДокторов',
    },
    {
      id: 2,
      name: 'Дмитрий Соколов',
      image:
        'https://images.unsplash.com/photo-1611818967077-78c60776ecdf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWlsZSUyMHBhdGllbnQlMjBzYXRpc2ZpZWR8ZW58MXx8fHwxNzc1ODAyMzA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      rating: 5,
      text: 'Сделал внутрикоронковое отбеливание депульпированного зуба. Цвет выровнялся идеально! Спасибо за внимательность и индивидуальный подход.',
      source: 'Яндекс.Карты',
    },
    {
      id: 3,
      name: 'Елена Краснова',
      image:
        'https://images.unsplash.com/photo-1584516150909-c43483ee7932?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHBhdGllbnQlMjB0ZXN0aW1vbmlhbHxlbnwxfHx8fDE3NzU3MTg5MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      rating: 5,
      text: 'Композитные виниры сделали за 2 визита. Зубы выглядят естественно и красиво! Очень довольна, что не стала делать обточку под керамику. Спасибо за профессионализм!',
      source: 'Google Reviews',
    },
    {
      id: 4,
      name: 'Александр Волков',
      image:
        'https://images.unsplash.com/photo-1611818967077-78c60776ecdf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWlsZSUyMHBhdGllbnQlMjBzYXRpc2ZpZWR8ZW58MXx8fHwxNzc1ODAyMzA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      rating: 5,
      text: 'Профессиональное отбеливание дало потрясающий результат! Зубы стали белее на несколько тонов. Врач все подробно объяснила и проконтролировала процесс.',
      source: 'ПроДокторов',
    },
  ];

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-6">Отзывы пациентов</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-4"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Что говорят те, кто уже доверил мне свою улыбку
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow relative"
            >
              <Quote className="absolute top-8 right-8 w-12 h-12 text-blue-100" />

              <div className="flex items-center gap-4 mb-6 relative z-10">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h4 className="text-lg">{testimonial.name}</h4>
                  <div className="flex items-center gap-1 mt-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </div>
              </div>

              <p className="text-gray-700 leading-relaxed mb-4">{testimonial.text}</p>

              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <span className="text-sm text-gray-500">Источник: {testimonial.source}</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Video testimonials placeholder */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16 text-center"
        >
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-12 text-white max-w-4xl mx-auto">
            <h3 className="text-2xl md:text-3xl mb-4">Видео-отзывы</h3>
            <p className="text-blue-100 mb-6">
              Смотрите, что говорят мои пациенты о качестве лечения
            </p>
            <div className="aspect-video bg-white/10 rounded-xl flex items-center justify-center backdrop-blur-sm">
              <div className="text-center">
                <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="w-0 h-0 border-t-8 border-t-transparent border-l-12 border-l-white border-b-8 border-b-transparent ml-1"></div>
                </div>
                <p className="text-sm text-blue-100">Видео-отзывы будут доступны скоро</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
