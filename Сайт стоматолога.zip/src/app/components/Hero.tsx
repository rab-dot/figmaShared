import { motion } from 'motion/react';
import { Button } from './ui/button';

export function Hero() {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-blue-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-serif tracking-tight">
                Caring for Your{' '}
                <span className="italic" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Smile
                </span>
                , One Visit at a Time.
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 max-w-2xl">
                Врач-стоматолог Анна Иванова. Сочетаю доказательную медицину и современные технологии лечения зубов.
              </p>
            </div>

            <Button
              onClick={scrollToContact}
              size="lg"
              className="text-lg px-8 py-6 rounded-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              Записаться на консультацию →
            </Button>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-8 pt-4 opacity-40">
              <span className="text-sm uppercase tracking-wider">20+ научных статей</span>
              <span className="text-sm uppercase tracking-wider">Высшее мед. образование</span>
              <span className="text-sm uppercase tracking-wider">Современные технологии</span>
            </div>
          </motion.div>

          {/* Right Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1593636677199-11450abb6e7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBkZW50aXN0JTIwcHJvZmVzc2lvbmFsJTIwbWVkaWNhbCUyMHVuaWZvcm18ZW58MXx8fHwxNzc1ODAyMzAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Врач-стоматолог"
                className="w-full h-auto object-cover"
              />
              {/* Decorative overlay */}
              <div className="absolute top-8 right-8 bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium">Доступна для записи</span>
                </div>
              </div>
            </div>

            {/* Decorative elements */}
            <div className="absolute -z-10 top-1/4 -right-12 w-64 h-64 bg-blue-200 rounded-full blur-3xl opacity-30"></div>
            <div className="absolute -z-10 bottom-1/4 -left-12 w-64 h-64 bg-purple-200 rounded-full blur-3xl opacity-30"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
