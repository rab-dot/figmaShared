import { motion } from 'motion/react';
import { ClipboardList, Sparkles, Paintbrush, PaintBucket, Smile, Zap } from 'lucide-react';

export function Services() {
  const services = [
    {
      icon: ClipboardList,
      title: 'Консультация и план лечения',
      description: 'Детальный осмотр, диагностика и составление индивидуального плана лечения',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Sparkles,
      title: 'Профессиональная гигиена',
      description: 'Чистка полости рта с покрытием фтор-гелем для защиты эмали',
      color: 'from-purple-500 to-pink-500',
    },
    {
      icon: Paintbrush,
      title: 'Эстетическая реставрация',
      description: 'Лечение кариеса, устранение сколов зубов и дисколоритов',
      color: 'from-orange-500 to-red-500',
    },
    {
      icon: PaintBucket,
      title: 'Композитные виниры',
      description: 'Создание идеальной улыбки с помощью современных композитных материалов',
      color: 'from-green-500 to-teal-500',
    },
    {
      icon: Smile,
      title: 'Внутрикоронковое отбеливание',
      description: 'Walking Bleach для зубов, изменивших цвет после лечения каналов',
      color: 'from-indigo-500 to-purple-500',
    },
    {
      icon: Zap,
      title: 'Профессиональное отбеливание',
      description: 'Быстрый результат за один визит с использованием современных систем',
      color: 'from-pink-500 to-rose-500',
    },
  ];

  return (
    <section id="services" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-6">Услуги</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-4"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Комплексный подход к лечению с использованием современных технологий
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden"
            >
              {/* Gradient background on hover */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}
              ></div>

              <div className="relative">
                <div
                  className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br ${service.color} text-white rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-300`}
                >
                  <service.icon className="w-8 h-8" />
                </div>

                <h3 className="text-xl mb-3 group-hover:text-blue-600 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
