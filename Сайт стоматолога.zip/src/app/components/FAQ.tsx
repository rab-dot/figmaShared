import { motion } from 'motion/react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import { HelpCircle } from 'lucide-react';

export function FAQ() {
  const faqs = [
    {
      question: 'Больно ли отбеливать депульпированный зуб?',
      answer:
        'Нет, процедура абсолютно безболезненна, так как зуб уже депульпирован (нерв удален). Отбеливающий гель помещается внутрь зуба через специальное отверстие, и вы не чувствуете никакого дискомфорта. Процедура проходит комфортно и безопасно.',
    },
    {
      question: 'Насколько стабилен результат внутрикоронкового отбеливания?',
      answer:
        'При правильном уходе результат сохраняется от 2 до 5 лет. Стабильность зависит от индивидуальных особенностей и соблюдения рекомендаций врача. В случае необходимости процедуру можно повторить без вреда для зуба.',
    },
    {
      question: 'Почему нельзя просто поставить винир?',
      answer:
        'Установка винира требует обточки здоровых тканей зуба, что является инвазивным вмешательством. Мы придерживаемся принципа биологической целесообразности: сначала пробуем минимально инвазивные методы (отбеливание, реставрация), и только если они не дают результата, рассматриваем виниры.',
    },
    {
      question: 'Как долго длится процедура профессионального отбеливания?',
      answer:
        'Процедура занимает около 1-1.5 часов. Результат виден сразу после первого визита. В зависимости от исходного оттенка и желаемого результата может потребоваться 1-2 процедуры с интервалом в неделю.',
    },
    {
      question: 'Чем композитные виниры отличаются от керамических?',
      answer:
        'Композитные виниры создаются прямо во рту за один визит, не требуют сильной обточки зубов и стоят дешевле. Керамические виниры более долговечны, но требуют обточки и изготовления в лаборатории. Выбор зависит от клинической ситуации и ваших пожеланий.',
    },
    {
      question: 'Как часто нужно делать профессиональную гигиену?',
      answer:
        'Рекомендуется проводить профессиональную гигиену полости рта каждые 6 месяцев. При склонности к образованию налета и камня — каждые 3-4 месяца. Регулярная гигиена — это профилактика кариеса и заболеваний десен.',
    },
    {
      question: 'Можно ли отбеливать зубы во время беременности?',
      answer:
        'Профессиональное отбеливание не рекомендуется во время беременности и кормления грудью из соображений безопасности. В этот период можно провести профессиональную чистку и реминерализацию, а отбеливание отложить на более подходящее время.',
    },
    {
      question: 'Сколько времени занимает лечение кариеса?',
      answer:
        'Лечение одного зуба обычно занимает 40-60 минут. Это зависит от глубины и локализации кариеса. Я использую современные материалы и технологии, которые обеспечивают долговременный результат и максимальный комфорт во время процедуры.',
    },
  ];

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 rounded-full mb-6">
            <HelpCircle className="w-10 h-10 text-blue-600" />
          </div>
          <h2 className="text-4xl md:text-5xl mb-6">Часто задаваемые вопросы</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-4"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Ответы на самые популярные вопросы пациентов
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-4xl mx-auto"
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl px-6 border-none"
              >
                <AccordionTrigger className="text-left hover:no-underline py-6">
                  <span className="text-lg pr-4">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="text-gray-700 pb-6 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-12 text-center"
        >
          <p className="text-gray-600 mb-4">Не нашли ответ на свой вопрос?</p>
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="inline-flex items-center justify-center px-8 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
          >
            Задать вопрос
          </button>
        </motion.div>
      </div>
    </section>
  );
}
