import { Heart } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <h3 className="text-2xl mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              Анна Иванова
            </h3>
            <p className="text-gray-400">
              Врач-стоматолог. Сочетаю доказательную медицину и современные технологии лечения
              зубов.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg mb-4">Навигация</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => scrollToSection('about')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Обо мне
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('services')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Услуги
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('cases')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Кейсы
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('testimonials')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Отзывы
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('faq')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  FAQ
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('contact')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Контакты
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg mb-4">Контакты</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="tel:+79991234567" className="hover:text-white transition-colors">
                  +7 (999) 123-45-67
                </a>
              </li>
              <li>
                <a href="mailto:anna.ivanova@dental.ru" className="hover:text-white transition-colors">
                  anna.ivanova@dental.ru
                </a>
              </li>
              <li>Москва, ул. Примерная, д. 10</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-400 text-sm">
            © {currentYear} Анна Иванова. Все права защищены.
          </p>
          <p className="text-gray-400 text-sm flex items-center gap-2">
            Сделано с <Heart className="w-4 h-4 text-red-500 fill-red-500" /> для ваших улыбок
          </p>
        </div>
      </div>
    </footer>
  );
}
