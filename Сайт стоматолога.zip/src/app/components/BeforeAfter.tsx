import { useState, useRef } from 'react';
import { motion } from 'motion/react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Case {
  id: number;
  beforeImage: string;
  afterImage: string;
  situation: string;
  treatment: string;
  result: string;
}

export function BeforeAfter() {
  const sliderRef = useRef<Slider>(null);

  const cases: Case[] = [
    {
      id: 1,
      beforeImage:
        'https://images.unsplash.com/photo-1612283105368-36468f634599?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBiZWZvcmUlMjBhZnRlciUyMHRyZWF0bWVudHxlbnwxfHx8fDE3NzU4MDIzMDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      afterImage:
        'https://images.unsplash.com/photo-1611818967077-78c60776ecdf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWlsZSUyMHBhdGllbnQlMjBzYXRpc2ZpZWR8ZW58MXx8fHwxNzc1ODAyMzA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      situation: 'Дисколорит 1.1 зуба, оттенок А4',
      treatment: 'Внутрикоронковое отбеливание Opalescence Endo + фотоактивация',
      result: 'Достигнут оттенок А1, срок лечения — 2 визита',
    },
    {
      id: 2,
      beforeImage:
        'https://images.unsplash.com/photo-1684607633080-df59e6874367?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWV0aCUyMHdoaXRlbmluZyUyMHByb2NlZHVyZXxlbnwxfHx8fDE3NzU4MDIzMDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      afterImage:
        'https://images.unsplash.com/photo-1611818967077-78c60776ecdf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWlsZSUyMHBhdGllbnQlMjBzYXRpc2ZpZWR8ZW58MXx8fHwxNzc1ODAyMzA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      situation: 'Множественный кариес передних зубов, оттенок А3',
      treatment: 'Эстетическая реставрация композитными материалами + профессиональное отбеливание',
      result: 'Восстановлена форма и цвет зубов, достигнут оттенок А1, 3 визита',
    },
    {
      id: 3,
      beforeImage:
        'https://images.unsplash.com/photo-1770321119162-05c18fbcfdb9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjb25zdWx0YXRpb24lMjBleGFtaW5hdGlvbnxlbnwxfHx8fDE3NzU4MDIzMDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      afterImage:
        'https://images.unsplash.com/photo-1611818967077-78c60776ecdf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWlsZSUyMHBhdGllbnQlMjBzYXRpc2ZpZWR8ZW58MXx8fHwxNzc1ODAyMzA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      situation: 'Сколы передних зубов, неровная эмаль',
      treatment: 'Композитные виниры на 6 передних зубов',
      result: 'Идеальная форма и цвет, естественный вид, лечение за 2 визита',
    },
  ];

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 5000,
    pauseOnHover: true,
  };

  return (
    <section id="cases" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-6">Кейсы «До / После»</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-4"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Реальные результаты моей работы
          </p>
        </motion.div>

        <div className="max-w-5xl mx-auto relative">
          <Slider ref={sliderRef} {...settings}>
            {cases.map((case_) => (
              <div key={case_.id} className="px-4">
                <BeforeAfterSlider case={case_} />
              </div>
            ))}
          </Slider>

          {/* Custom navigation buttons */}
          <button
            onClick={() => sliderRef.current?.slickPrev()}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 bg-white rounded-full p-3 shadow-lg hover:shadow-xl transition-all hover:scale-110"
            aria-label="Previous case"
          >
            <ChevronLeft className="w-6 h-6 text-blue-600" />
          </button>
          <button
            onClick={() => sliderRef.current?.slickNext()}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 bg-white rounded-full p-3 shadow-lg hover:shadow-xl transition-all hover:scale-110"
            aria-label="Next case"
          >
            <ChevronRight className="w-6 h-6 text-blue-600" />
          </button>
        </div>
      </div>
    </section>
  );
}

function BeforeAfterSlider({ case: caseData }: { case: Case }) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);

  const handleMove = (clientX: number, rect: DOMRect) => {
    const x = clientX - rect.left;
    const percentage = (x / rect.width) * 100;
    setSliderPosition(Math.min(Math.max(percentage, 0), 100));
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const rect = e.currentTarget.getBoundingClientRect();
    handleMove(e.clientX, rect);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const rect = e.currentTarget.getBoundingClientRect();
    handleMove(e.touches[0].clientX, rect);
  };

  return (
    <div className="space-y-8">
      {/* Before/After Image Slider */}
      <div
        className="relative aspect-[16/10] rounded-2xl overflow-hidden shadow-2xl cursor-ew-resize select-none"
        onMouseDown={() => setIsDragging(true)}
        onMouseUp={() => setIsDragging(false)}
        onMouseLeave={() => setIsDragging(false)}
        onMouseMove={handleMouseMove}
        onTouchStart={() => setIsDragging(true)}
        onTouchEnd={() => setIsDragging(false)}
        onTouchMove={handleTouchMove}
      >
        {/* After Image (bottom layer) */}
        <img
          src={caseData.afterImage}
          alt="После лечения"
          className="absolute inset-0 w-full h-full object-cover"
          draggable={false}
        />

        {/* Before Image (top layer with clip) */}
        <div
          className="absolute inset-0 overflow-hidden"
          style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
        >
          <img
            src={caseData.beforeImage}
            alt="До лечения"
            className="absolute inset-0 w-full h-full object-cover"
            draggable={false}
          />
        </div>

        {/* Slider Handle */}
        <div
          className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-10"
          style={{ left: `${sliderPosition}%` }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center">
            <div className="flex gap-1">
              <ChevronLeft className="w-4 h-4 text-blue-600" />
              <ChevronRight className="w-4 h-4 text-blue-600" />
            </div>
          </div>
        </div>

        {/* Labels */}
        <div className="absolute top-4 left-4 bg-black/70 text-white px-4 py-2 rounded-full text-sm">
          До
        </div>
        <div className="absolute top-4 right-4 bg-black/70 text-white px-4 py-2 rounded-full text-sm">
          После
        </div>
      </div>

      {/* Case Details */}
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 space-y-4">
        <div>
          <h4 className="text-sm uppercase tracking-wider text-blue-600 mb-2">
            Исходная ситуация
          </h4>
          <p className="text-lg">{caseData.situation}</p>
        </div>
        <div>
          <h4 className="text-sm uppercase tracking-wider text-purple-600 mb-2">
            Проведенная работа
          </h4>
          <p className="text-lg">{caseData.treatment}</p>
        </div>
        <div>
          <h4 className="text-sm uppercase tracking-wider text-green-600 mb-2">Результат</h4>
          <p className="text-lg">{caseData.result}</p>
        </div>
      </div>
    </div>
  );
}
