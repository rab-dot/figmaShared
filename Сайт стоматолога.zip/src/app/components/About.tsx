import { motion } from 'motion/react';
import { Award, BookOpen, GraduationCap } from 'lucide-react';

export function About() {
  const achievements = [
    {
      icon: GraduationCap,
      title: 'Высшее медицинское образование',
      description: 'МГМСУ им. А.И. Евдокимова, специальность "Стоматология"',
    },
    {
      icon: BookOpen,
      title: '20+ научных статей',
      description: 'Публикации в ведущих российских и международных журналах',
    },
    {
      icon: Award,
      title: 'Постоянное обучение',
      description: 'Регулярное участие в семинарах, мастер-классах и конференциях',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-6xl mx-auto"
        >
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl mb-6">Обо мне</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {achievements.map((achievement, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-blue-50 rounded-2xl p-8 text-center hover:shadow-lg transition-shadow"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 text-white rounded-full mb-4">
                  <achievement.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl mb-3">{achievement.title}</h3>
                <p className="text-gray-600">{achievement.description}</p>
              </motion.div>
            ))}
          </div>

          {/* Professional Credo */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-12 text-white text-center"
          >
            <blockquote className="text-2xl md:text-3xl italic" style={{ fontFamily: 'Playfair Display, serif' }}>
              "Минимальная инвазивность — максимальный эстетический результат"
            </blockquote>
            <p className="mt-4 text-blue-100">Мое профессиональное кредо</p>
          </motion.div>

          {/* Certificates Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-16"
          >
            <h3 className="text-2xl text-center mb-8">Сертификаты и дипломы</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="relative aspect-[3/4] rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-shadow"
                >
                  <img
                    src="https://images.unsplash.com/photo-1638636241638-aef5120c5153?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50aXN0JTIwY2VydGlmaWNhdGUlMjBkaXBsb21hfGVufDF8fHx8MTc3NTgwMjMwNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt={`Сертификат ${i}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
