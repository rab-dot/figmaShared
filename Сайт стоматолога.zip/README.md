
  # Сайт стоматолога

  This is a code bundle for Сайт стоматолога. The original project is available at https://www.figma.com/design/KLFrnp1Q7uM1cYiheL2TXR/%D0%A1%D0%B0%D0%B9%D1%82-%D1%81%D1%82%D0%BE%D0%BC%D0%B0%D1%82%D0%BE%D0%BB%D0%BE%D0%B3%D0%B0.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  